module.exports = require("@uma/common").SolcoverConfig;
